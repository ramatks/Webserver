<?php 
 include ('session.php');
 include("includes/database.php");

$pid=$_GET['id'];
$select2=mysqli_query($conn,"select * from domain where domain_id='$pid' ");
$result2=mysqli_fetch_array($select2);




 ?>