          
<?php
include('/includes/database.php');


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webserver";

// Create connection
$conn= mysqli_connect($servername,$username,$password,$dbname);


            if(isset($_POST['submit']))
            {
              $customer_email=$_POST['customer_email'];
              $customer_password=$_POST['customer_password'];
            {
          $result = mysqli_query($conn, "SELECT * FROM customer WHERE customer_email = '$customer_email' and customer_password='$customer_password'") or die(mysqli_error());
              
              $row = mysqli_fetch_array($result);
              $count = mysqli_num_rows($result);        
                if ($count == 0) 
                  {
                  echo "<script>alert('Please check your username and password!'); window.location='cust_login.php'</script>";
                  } 
                else if ($count > 0)
                  {
                    session_start();
                    $_SESSION['id'] = $row['customer_id'];
                    header("location:cust_home.php");
                  }
            }       
            }
?>



