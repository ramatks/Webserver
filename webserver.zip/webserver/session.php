<?php
include("includes/database.php");
session_start();
if (!isset($_SESSION['id'])){
header('location:index.php');
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webserver";
// Create connection
$conn= mysqli_connect($servername,$username,$password,$dbname);

$id = $_SESSION['id'];

$query=mysqli_query ($conn,"SELECT * FROM customer WHERE customer_id ='$id'") or die(mysql_error());
$row=mysqli_fetch_array($query);
$customer_id=$row['customer_id'];
$customer_name=$row['customer_name'];
$customer_email=$row['customer_email']; 
// $firstname=$row['firstname'];
// $lastname=$row['lastname'];
// $username=$row['username'];
?>