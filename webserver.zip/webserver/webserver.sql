-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2021 at 02:14 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webserver`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(100) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_email` varchar(100) NOT NULL,
  `admin_password` varchar(100) NOT NULL,
  `customer_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_email`, `admin_password`, `customer_id`) VALUES
(25, 'swabi', 'swabi@gmail.com', '123', ''),
(26, 'awa', 'awa@gmail.com', '123', ''),
(27, 'ubada', 'ubada@gmail.com', '123', ''),
(28, 'ubada', 'ubada1@gmail.com', '123', '');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(100) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `customer_password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_name`, `customer_email`, `customer_password`) VALUES
(15, 'Asuman', 'asuman@gmail.com', '123'),
(17, 'man', 'man@gmail.com', '123'),
(19, 'AlphaSDN', 'ubadaabbas@iut-dhaka.edu', 'aldo987'),
(20, 'halima', 'halima@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `domain`
--

CREATE TABLE `domain` (
  `domain_id` int(100) NOT NULL,
  `domain_name` varchar(100) NOT NULL,
  `customer_id` varchar(100) NOT NULL,
  `domain_file` varchar(100) NOT NULL,
  `start_date` varchar(11) NOT NULL,
  `end_date` varchar(100) NOT NULL,
  `domain_duration` varchar(11) NOT NULL,
  `invoice_no` int(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `domain`
--

INSERT INTO `domain` (`domain_id`, `domain_name`, `customer_id`, `domain_file`, `start_date`, `end_date`, `domain_duration`, `invoice_no`) VALUES
(76, 'aldoSDN.com', '19', '1627460642.zip', '28,07,2021', '28,07,2022', '1', 0),
(78, 'heii.com', '18', '1627480259.zip', '28,07,2021', '28,07,2022', '1', 0),
(90, 'jaja.com', '17', '1633687767.zip', '14,08,2021', '14,08,2022', '1', 0),
(91, 'uganda.com', '17', '1629905721.zip', '25,08,2021', '25,08,2022', '1', 0),
(92, 'invoice.com', '17', '1630146043.zip', '28,08,2021', '28,08,2022', '1', 66123),
(93, 'fanta.com', '17', '1633337668.zip', '04,10,2021', '04,10,2022', '2', 49300),
(98, 'hai2.com', '15', '1633633104.zip', '07,10,2021', '07,10,2022', '1', 95127),
(99, 'hai3.com', '15', '1633633160.zip', '07,10,2021', '07,10,2022', '1', 97923),
(100, 'iut.com', '20', '1633683198.zip', '08,10,2021', '08,10,2022', '1', 51943),
(101, 'sds.com', '17', '1633687508.zip', '08,10,2021', '08,10,2022', '1', 80669);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(70) NOT NULL,
  `amount` int(70) NOT NULL,
  `agent_id` int(20) NOT NULL,
  `customer_id` int(70) NOT NULL,
  `domain_id` int(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `amount`, `agent_id`, `customer_id`, `domain_id`) VALUES
(1, 2000, 322544, 17, 0),
(2, 2500, 111123, 17, 0),
(3, 2500, 123000, 17, 0),
(4, 2500, 322544, 17, 0),
(5, 2500, 111111, 17, 0),
(6, 2500, 123000, 15, 0),
(7, 2000, 111111, 15, 0),
(8, 2000, 111123, 15, 0),
(9, 2500, 123000, 15, 0),
(10, 2500, 111111, 20, 0),
(11, 2500, 111123, 17, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `domain_name` text NOT NULL,
  `description` varchar(255) NOT NULL,
  `customer_id` int(70) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`ticket_id`, `title`, `domain_name`, `description`, `customer_id`, `date`) VALUES
(1, 'website is slow', '', 'hello Mr. man,,, the website has been so slow since last night', 17, '2021-10-05 02:21:18'),
(2, 'hello', '', 'Uganda\r\nKenya \r\nTanzania', 17, '2021-10-05 02:22:02'),
(3, 'Test 3', '', 'clear package233', 17, '2021-10-05 02:24:58'),
(4, 'insecurity', 'uganda.com', 'problems, problems all day everyday', 17, '2021-10-05 02:42:02'),
(5, 'website crashed', 'iut.com', 'aksjaksjaksaksaska', 20, '2021-10-08 14:54:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `domain`
--
ALTER TABLE `domain`
  ADD PRIMARY KEY (`domain_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `domain`
--
ALTER TABLE `domain`
  MODIFY `domain_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(70) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
