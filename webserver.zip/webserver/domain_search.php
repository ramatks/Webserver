<?php
			           include ('includes/database.php');
						if(isset($_POST['submit']))
						{
						$domain_name=$_POST['domain_name'];

			$sql1=mysqli_query($conn, "select * from domain WHERE domain_name='$domain_name'") or die (mysqli_error($conn));
			$row=mysqli_num_rows($sql1);
			if ($row > 0)
			{
			echo "<script>alert('Domain already Taken!'); window.location='index.php'</script>";
			// echo "taken";
			}
			else
			echo "<script>alert('Domain Available'); window.location='index.php'</script>";
		
	}
			?>
