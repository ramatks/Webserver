          
<?php
include('../includes/database.php');


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webserver";

// Create connection
$conn= mysqli_connect($servername,$username,$password,$dbname);


            if(isset($_POST['submit']))
            {
              $admin_email=$_POST['admin_email'];
              $admin_password=$_POST['admin_password'];
            {
          $result = mysqli_query($conn, "SELECT * FROM admin WHERE admin_email = '$admin_email' and admin_password='$admin_password'") or die(mysqli_error());
              
              $row = mysqli_fetch_array($result);
              $count = mysqli_num_rows($result);        
                if ($count == 0) 
                  {
                  echo "<script>alert('Please check your username and password!'); window.location='admin_login.php'</script>";
                  } 
                else if ($count > 0)
                  {
                    session_start();
                    $_SESSION['id'] = $row['admin_id'];
                    header("location:admin_home.php");
                  }
            }       
            }
?>

