<?php
  include ('../../includes/database.php');


  
  if (isset($_POST['submit']))
  {
    $admin_name=$_POST['admin_name'];
    $admin_email=$_POST['admin_email'];
    $admin_password=$_POST['admin_password'];
    $password2=$_POST['password2'];
  
    
      $sql=mysqli_query($conn, "select * from admin WHERE admin_email='$admin_email'") or die (mysqli_error($conn));
      $row=mysqli_num_rows($sql);
      if ($row > 0)
      {
      echo "<script>alert('E-mail already taken!'); window.location='admin_signup.php'</script>";
      }
      elseif($admin_password != $password2)
      {
      echo "<script>alert('Passwords do not match!'); window.location='admin_signup.php'</script>";
      }else
    {
      mySQLi_query($conn, "INSERT INTO admin (admin_name, admin_email, admin_password)
      VALUES ('$admin_name','$admin_email','$admin_password')")
      or die (mysqli_error());
      echo "<script>alert('Account successfully created!'); window.location='../'</script>";
    }
      
  }
  
?>
