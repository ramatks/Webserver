

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="../style.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="../css/versions.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="../css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../css/custom.css">

    <!-- Modernizer for Portfolio -->
    <script src="../js/modernizer.js"></script>

    <style>
        .div2{
    background-color: greenyellow;
    }

    * {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
    </style>
   
</head>

<body>
<!-- <div id="preloader">
        <div class="loader-container">
            <div class="progress-br float shadow">
                <div class="progress__item"></div>
            </div>
        </div>
    </div> -->
    <!-- END LOADER --> 

    <?php include ('session.php');?>
    
    <!-- Start header -->
    <header class="top-navbar">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">
                    <!-- <img src="images/logo-hosting.png" alt="" /> -->
                    <b><h1 style="color: white;">WEBSERVER</h1><b></b>
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbars-host" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbars-host">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active"><a class="nav-link" href="index.php">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#"><?php echo $admin_name ?></a></li>
                        <li class="nav-item"><a class="nav-link" href="tickets.php">Tickets</a></li>
                        <li class="nav-item"><a class="nav-link" href="domains.php">Domains</a></li>
                        <!-- <li class="nav-item"><a class="nav-link" href="features.html">Features </a></li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="dropdown-a" data-toggle="dropdown">Hosting </a>
                            <div class="dropdown-menu" aria-labelledby="dropdown-a">
                                <a class="dropdown-item" href="#">Web Hosting </a>
                                <a class="dropdown-item" href="#">WordPress Hosting </a>
                                <a class="dropdown-item" href="#">Cloud Server </a>
                                <a class="dropdown-item" href="#">Reseller Package </a>
                                <a class="dropdown-item" href="#">Dedicated Hosting </a>
                            </div>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="domain.html">Domain</a></li>
                        <li class="nav-item"><a class="nav-link" href="pricing.html">Pricing</a></li> -->
                        <!-- <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li> -->
                       <!--  <li class="nav-item"><a class="nav-link" href="#"></a></li> -->
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a class="hover-btn-new log" href="logout.php"><span>Log Out</span></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- End header -->




            <section class="main" id="content">
 <br><br>  


            <b><h1 style="color: red;"><strong>All Customers</strong></h1></b>
            <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search by Email.." title="Type in a name">
            <table id="myTable" class="table table-striped">
            <thead>
           <strong><th>Customer Email</th></strong>
            <strong><th>Customer Name</th></strong>
            <!-- <th>Start Date</th>
            <th>End Date</th> -->
            <th>Options</th>
            <strong><th>#</th></strong>
            </thead>
            <tbody>

<?php

      include ('../includes/database.php');

     $sn=1;
     $select=mysqli_query($conn, "select * from customer");
     while($selected=mysqli_fetch_assoc($select)){   
 ?>        
            <tr>
            <td><?php  echo $selected['customer_email'] ?> </td>
            <td><?php  echo $selected['customer_name'] ?> </td>
            <!-- <td>3/12/2020</td>
            <td>2/12/2021</td> -->
            <td align="">
                <a href="../forms/editproduct.php?id=<?php echo $result['id']; ?>"><button type="submit" name="submit" class="btn btn-primary btn-sm">Edit</button></a>
                <a href="view_customer.php?id=<?php  echo $selected['customer_id'];?>"><button type="submit" name="submit" class="btn btn-success btn-sm">View</button></a>
                <a href="delete_customer.php?id=<?php  echo $selected['customer_id']; ?>"><button type="submit" name="submit" Onclick="return confirm('Are you sure you want to Delete')" class="btn btn-danger btn-sm">Delete</button></a>
            </td>
            <td><?php  echo $sn ?></td>
            </tr>

  <?php $sn++; }?>      
            </tbody>
            </table>
            </section>

    
    <script>
       

        function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
    </script>
     <script src="javascript.js"></script>,
</body>
</html>



 
