<?php
 include ('../includes/database.php');
$cid=$_GET['id'];

$sql=mysqli_query($conn, "delete from domain where domain_id='$cid'");
if($sql)
{
	 header("location:admin_home.php");
}
else
{
	echo "Error Deleting Record ".mysqli_error($conn);
}


?>