
<!DOCTYPE html>
<html>
<head>
<title>SignUp Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/registration.css">
  <script src="../js/registration.js"></script>
  <style>
    body{
      background-color: lightblue;
    }
  </style>

</head>
<body>
  <!-- main -->
  <div class="main-w3layouts wrapper">
    <h1>SignUp Admin</h1>
    <div class="main-agileinfo">
      <div class="agileits-top">
        <form method="post" action="admin_signup_process.php" enctype="multipart/form-data">
          <input class="text" type="text" name="admin_name" placeholder="Username" required="">
          <input class="text email" type="email" name="admin_email" placeholder="Email" required="">
          <input class="text" type="password" name="admin_password" placeholder="Password" required="">
          <input class="text w3lpass" type="password" name="password2" placeholder="Confirm Password" required="">
          <div class="wthree-text">
            <label class="anim">
              <input type="checkbox" class="checkbox" required="">
              <span>I Agree To The Terms & Conditions</span>
            </label>
            <div class="clear"> </div>
          </div>
          <input type="submit" name="submit" value="SIGNUP">
        </form>
        
      </div>
    </div>
   
  
</body>
</html>
  
</body>
</html>