<?php include ('session.php');







?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="css/versions.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!-- Modernizer for Portfolio -->
    <script src="js/modernizer.js"></script>

    <style>
        .div2{
    background-color: greenyellow;
}
    </style>
   
</head>

<body>

 
    <!-- Start header -->
    <header class="top-navbar">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">
                    <!-- <img src="images/logo-hosting.png" alt="" /> -->
                    <b><h1 style="color: white;">WEBSERVER</h1><b></b>
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbars-host" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbars-host">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active"><a class="nav-link" href="index.php">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#"><?php echo $customer_name ?></a></li>
                       
                        
                        <!-- <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li> -->
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a class="hover-btn-new log" href="logout.php"><span>Log Out</span></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- End header -->



            <section class="main" id="content">

                      <div class="jumbotron">
  <h1 class="display-4"><b>Submit your Issue, We fix it</b> </h1>
  <p class="lead">information.</p>
  <hr class="my-4">
  <p class="lead">
    <!-- <a class="btn btn-primary btn-lg" href="view_domain.php" role="button">Back</a> -->
  </p>
</div><br><br><br>
               


        <form class="form-control" method="post" action="" enctype="multipart/form-data">
            <fieldset>
                <legend>Complaint About your Domain and Hosting</legend>
                <div class="form-control">
                    <input type="text" id="title" for="title" placeholder="Title" name="title" required>
                    <span id="id-warning"
                    style="color: red; visibility: visible; font-weight: bold;"><small></small></span></br></br>
                </div><br>

                  <div class="form-control">
                    <input type="text" id="title" for="domain_name" placeholder="Domain or Invoice_ID" name="domain_name" required>
                    <span id="id-warning"
                    style="color: red; visibility: visible; font-weight: bold;"><small></small></span></br></br>
                </div><br>
               

                 <div class="form-group">
                      
                      <textarea   type="text" id="description" for="description" placeholder="Description" name="description" required class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                     </div>
                    
                
                <button style="margin-left: 10px; margin-top: 10px; background-color:darkblue;" id="addbtn" name="submit"  type="submit" r>Submit</button><br>
                <!--<span  id="warning" style="color: red; visibility: hidden; font-weight: bold;">*All fields are required</span><br> -->
            </fieldset>
    </form><br><br><br>
    <?php
    // $date = date('d,m,Y');
    // $invoice_no = rand(10000,99999);
    // echo"$date";
    
    // $end = date('d,m,Y', strtotime('+$domain_duration years'));
    // $end = date('d,m,Y', strtotime('+1 years'));

   

if(isset($_POST['submit']))
{
    

// $domain_name=$_POST['domain_name'];
// $domain_duration=$_POST['domain_duration'];

$title=$_POST['title'];
$domain_name=$_POST['domain_name'];
$description=$_POST['description'];
// $end = date('d,m,Y', strtotime('+1 years'));
// $category=$_POST['category'];
// $price=$_POST['price'];
// $desc=$_POST['desc'];


//     if(empty($_FILES['domain_file']['tmp_name'])){
//     echo"<script>alert('upload a file first'); window.location='cust_home.php'</script>";
//     die();
// }

  // if(!empty($_FILES['domain_file']['tmp_name'])){
  //           $picture_file1 = $_FILES['domain_file']['tmp_name'];
  //           $picture_name1 = $_FILES['domain_file']['name'];
  //           $temp1 = explode(".", $picture_name1);
  //           $newfilename1 = round(microtime(true)) . '.' . end($temp1);
  //           $path = "upload/$domain_name";
  //           if(!file_exists($path)) {
  //               mkdir($path, 0755, true);
  //           }
  //           move_uploaded_file($_FILES["domain_file"]["tmp_name"], "upload/".$domain_name."/"  .$newfilename1);
  //     }

      


//  $sql1=mysqli_query($conn, "select * from domain WHERE domain_name='$domain_name'") or die (mysqli_error($conn));
//       $row=mysqli_num_rows($sql1);
//       if ($row > 0)
//       {
//       echo "<script>alert('Domain already Taken!'); window.location='cust_home.php'</script>";
//       }
//       else

// {
$sql=mysqli_query($conn, "insert into tickets (title, domain_name, description, customer_id)
                          values('$title', '$domain_name', '$description', '$customer_id')");
    if($sql)
    {
        echo "<script>alert('Ticket is saved Successful'); window.location='#'</script>";
        // echo "successfully";
    }
    else 
    {
        echo "<script>alert('error saving Ticket '); window.location='cust_ticket.php'</script>".mysqli_error($conn);
    }

}



?>             








          
            </section>


    
    <script src="">
        let tbn = document.getElementsByClassName("delbtn");
        btn.addEventListener('click', function (params) {

        })
    </script>
     <script src="javascript.js"></script>
</body>
</html>



 
