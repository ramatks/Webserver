


<!DOCTYPE html>
<html lang="en">

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
     <!-- Site Metas -->
    <title>webserver</title>  
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="css/versions.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSSdd -->
    <link rel="stylesheet" href="css/custom.css">

    <!-- Modernizer for Portfolio -->
    <script src="js/modernizer.js"></script>

    <style>
    	.div2{
    background-color: greenyellow;
}
    </style>

    

</head>
<body class="host_version"> 


    <!-- LOADER -->
	<div id="preloader">
		<div class="loader-container">
			<div class="progress-br float shadow">
				<div class="progress__item"></div>
			</div>
		</div>
	</div>
	<!-- END LOADER -->	
	
	<!-- Start header -->
	<header class="top-navbar">
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<div class="container-fluid">
				<a class="navbar-brand" href="index.php">
					<!-- <img src="images/logo-hosting.png" alt="" /> -->
					<b><h1 style="color: white;">WEBSERVER</h1><b></b>
				</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbars-host" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbars-host">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item active"><a class="nav-link" href="#">Home</a></li>
						<!-- <li class="nav-item"><a class="nav-link" href="about.html">About Us</a></li>
						<li class="nav-item"><a class="nav-link" href="features.html">Features </a></li>
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" href="#" id="dropdown-a" data-toggle="dropdown">Hosting </a>
							<div class="dropdown-menu" aria-labelledby="dropdown-a">
								<a class="dropdown-item" href="#">Web Hosting </a>
								<a class="dropdown-item" href="#">WordPress Hosting </a>
								<a class="dropdown-item" href="#">Cloud Server </a>
								<a class="dropdown-item" href="#">Reseller Package </a>
								<a class="dropdown-item" href="#">Dedicated Hosting </a>
							</div>
						</li>
						<li class="nav-item"><a class="nav-link" href="domain.html">Domain</a></li>
						<li class="nav-item"><a class="nav-link" href="pricing.html">Pricing</a></li>
						<li class="nav-item"><a class="nav-link" href="#">Contact</a></li> -->
						<li class="nav-item"><a class="nav-link" href="#"></a></li> 
						<li class="nav-item"><a class="nav-link" href="#"></a></li> 
						<li class="nav-item"><a class="nav-link" href="#"></a></li> 
						<li class="nav-item"><a class="nav-link" href="#"></a></li> 
						<li class="nav-item"><a class="nav-link" href="#"></a></li> 
						<li class="nav-item"><a class="nav-link" href="#"></a></li> 
						<li class="nav-item"><a class="nav-link" href="#"></a></li> 
						<li class="nav-item"><a class="nav-link" href="#"></a></li> 
						<li class="nav-item"><a class="nav-link" href="#"></a></li> 
						<li class="nav-item"><a class="nav-link" href="#"></a></li> 
						<li class="nav-item"><a class="nav-link" href="#"></a></li> 
						<li class="nav-item"><a class="nav-link" href="#"></a></li> 
						<li class="nav-item"><a class="nav-link" href="#"></a></li> 
						<li class="nav-item"><a class="nav-link" href="#"></a></li> 
						<li class="nav-item"><a class="nav-link" href="#"></a></li> 
						<li class="nav-item"><a class="nav-link" href="#"></a></li> 

					</ul>
					<ul class="nav navbar-nav navbar-right">
                        <li><a class="hover-btn-new log" href="cust_login.php"><span>Customer Login</span></a></li>
                    </ul>
				</div>
			</div>
		</nav>
	</header>
	<!-- End header -->
	
	<div id="carouselExampleControls" class="carousel slide bs-slider box-slider" data-ride="carousel" data-pause="hover" data-interval="false" >
		<!-- Indicators -->
		<ol class="carousel-indicators">
			<li data-target="#carouselExampleControls" data-slide-to="0" class="active"></li>
			
		</ol>
		<div class="carousel-inner" role="listbox">
			<div class="carousel-item active">
				<div id="home" class="first-section" style="background-image:url('images/cust1.jpg');">
					<div class="dtab">
						<div class="container">
							<div class="row">
								<div class="col-md-12 col-sm-12 text-right">
									<div class="big-tagline">
										<h2><strong>webserver</strong> Company</h2>
										<p class="lead">Come and support Us </p>
											<a href="#" class="hover-btn-new"><span>Contact Us</span></a>
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<a href="#" class="hover-btn-new"><span>Read More</span></a> 
									</div>
								</div>
							</div><!-- end row -->            
						</div><!-- end container -->
					</div>
				</div><!-- end section -->
			</div>
			<!-- <div class="carousel-item">
				<div id="home" class="first-section" style="background-image:url('images/2.jpg');">
					<div class="dtab">
						<div class="container">
							<div class="row">
								<div class="col-md-12 col-sm-12 text-left">
									<div class="big-tagline">
										<h2 data-animation="animated zoomInRight">Find the right <strong>Hosting</strong></h2>
										<p class="lead" data-animation="animated fadeInLeft">With Landigoo responsive landing page template, you can promote your all hosting, domain and email services. </p>
											<a href="#" class="hover-btn-new"><span>Contact Us</span></a>
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<a href="#" class="hover-btn-new"><span>Read More</span></a>
									</div>
								</div> -->
							</div><!-- end row -->            
						</div><!-- end container -->
					</div>
				</div><!-- end section -->
			</div>
			<!-- <div class="carousel-item">
				<div id="home" class="first-section" style="background-image:url('images/3.jpg');">
					<div class="dtab">
						<div class="container">
							<div class="row">
								<div class="col-md-12 col-sm-12 text-center">
									<div class="big-tagline">
										<h2 data-animation="animated zoomInRight"><strong>VPS Servers</strong> Company</h2>
										<p class="lead" data-animation="animated fadeInLeft">1 IP included with each server 
											Your Choice of any OS (CentOS, Windows, Debian, Fedora)
											FREE Reboots</p>
											<a href="#" class="hover-btn-new"><span>Contact Us</span></a>
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<a href="#" class="hover-btn-new"><span>Read More</span></a>
									</div>
								</div> -->
							</div><!-- end row -->            
						</div><!-- end container -->
					</div>
				</div><!-- end section -->
			</div>
			<!-- Left Control -->
			<a class="new-effect carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
				<span class="fa fa-angle-left" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>

			<!-- Right Control -->
			<a class="new-effect carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
				<span class="fa fa-angle-right" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>
	</div><br><br>
	<section class="container">
		
		  <form class="form-control" method="post" action="domain_search.php" enctype="multipart/form-data">
            <fieldset>
                <legend>Domain Search</legend>
                <div class="form-control">
                    <input type="text" id="pname" for="name" placeholder="domain.com" name="domain_name">
                    <span id="id-warning"
                    style="color: red; visibility: visible; font-weight: bold;"><small></small></span></br></br>
                </div>
                
                <button style="margin-left: 10px; margin-top: 10px; background-color:green;" id="addbtn" name="submit"  type="submit">Search</button><br>
                <!--<span  id="warning" style="color: red; visibility: hidden; font-weight: bold;">*All fields are required</span><br> -->
            </fieldset>
    </form><br><br><br>
	</section>


    <div id="pricing" class="section lb">
        <div class="container">
            

            <hr class="invis">

            <div class="row">
                <div class="col-md-12">
                    <div class="tab-content">
                        <div class="tab-pane active fade show" id="tab1">
                            <div class="row text-center">
                                <div class="col-md-4">
                                    <div class="pricing-table pricing-table-highlighted">
                                        <div class="pricing-table-header grd1">
                                            <h2>BKash Numbers</h2>
                                    
                                        </div>
                                        <div class="pricing-table-space"></div>
                                        <div class="pricing-table-features">
                                            <p><i class="fa fa-envelope-o"></i> <strong>0184737373250</strong></p>
                                            <p><i class="fa fa-envelope-o"></i> <strong>01873828282</strong></p>
                                            <p><i class="fa fa-envelope-o"></i> <strong>09272772222</strong></p>
                                            <p><i class="fa fa-envelope-o"></i> <strong>06372727288</strong></p>
                                            <p><i class="fa fa-envelope-o"></i> <strong>04527272222</strong></p>
                                            
                                            
                                        </div>
                                  
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="pricing-table pricing-table-highlighted">
                                        <div class="pricing-table-header grd1">
                                            <h2>Service Prices</h2>
                                       
                                        </div>
                                        <div class="pricing-table-space"></div>
                                        <div class="pricing-table-features">
                                          
                                            <p><i class="fa fa-rocket"></i> <strong>Basic</strong> 1500 taka</p>
                                            <p><i class="fa fa-rocket"></i> <strong>Premium</strong>2000 taka</p>
                                            <p><i class="fa fa-rocket"></i> <strong>Basic 2</strong>1700 taka</p>
                                            <p><i class="fa fa-rocket"></i> <strong>Premium 2</strong>2300 taka</p>
                                            <p><i class="fa fa-rocket"></i> <strong>Super Premium</strong>2500 taka</p>
                                          
                                        </div>
                                      
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="pricing-table pricing-table-highlighted">
                                        <div class="pricing-table-header grd1">
                                            <h2>Contact Us</h2>
                             
                                        </div>
                                        <div class="pricing-table-space"></div>
                                        <div class="pricing-table-features">
                                            
                                            <p><i class="fa fa-link"></i> <strong>078448833933</strong></p>
                                            <p><i class="fa fa-link"></i> <strong>078448833933</strong></p>
                                            <p><i class="fa fa-link"></i> <strong>078448833933</strong></p>
                                            <p><i class="fa fa-link"></i> <strong>078448833933</strong></p>
                                            <p><i class="fa fa-link"></i> <strong>078448833933</strong></p>
                                            
                                        </div>
                                       
                                    </div>
                                </div>
                            </div><!-- end row -->
                        </div><!-- end pane -->

                       
                                    </div>
                                </div>
                            </div><!-- end row -->
                        </div><!-- end pane -->
                    </div><!-- end content -->
                </div><!-- end col -->
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->


    <!-- ALL JS FILES -->
    <script src="js/all.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/custom.js"></script>
	<script src="js/timeline.min.js"></script>
	<script>
		timeline(document.querySelectorAll('.timeline'), {
			forceVerticalMode: 700,
			mode: 'horizontal',
			verticalStartPosition: 'left',
			visibleItems: 4
		});
	</script>
</body>
</html>