<!-- <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="css/registration.css">
  <script src="js/registration.js"></script> -->

<!-- <body>

Author: Colorlib
Author URL: https://colorlib.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>loginform</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/registration.css">
  <script src="js/registration.js"></script>
<!-- //Custom Theme files d-->
<!-- web font -->
<!-- <link href="//fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,700,700i" rel="stylesheet"> -->
<!-- //web font -->
</head>
<body>
  <!-- main -->
  <div class="main-w3layouts wrapper">
    <h1>LOGIN HERE</h1>
    <div class="main-agileinfo">
      <div class="agileits-top">
        <form method="post" action="cust_login_process.php" enctype="multipart/form-data">
          <input class="text email" type="email" name="customer_email" placeholder="Email" required="">
          <input class="text" type="password" name="customer_password" placeholder="Password" required="">
          <div class="wthree-text">
            <label class="anim">
              <input type="checkbox" class="checkbox" required="">
              <span>I Agree To The Terms & Conditions</span>
            </label>
            <div class="clear"> </div>
          </div>
          <input type="submit" name="submit" value="LOGIN">
        </form>
        <p>Don't have an Account? <a href="cust_signup.php"> Signup Now!</a></p>
      </div>
    </div>
   
  
</body>
</html>
  
</body>
</html>