
<?php
  include ('includes/database.php');


  
  if (isset($_POST['submit']))
  {
    $customer_name=$_POST['customer_name'];
    $customer_email=$_POST['customer_email'];
    $customer_password=$_POST['customer_password'];
    $password2=$_POST['password2'];
  
    
      $sql=mysqli_query($conn, "select * from customer WHERE customer_email='$customer_email'") or die (mysqli_error($conn));
      $row=mysqli_num_rows($sql);
      if ($row > 0)
      {
      echo "<script>alert('E-mail already taken!'); window.location='cust_signup.php'</script>";
      }
      elseif($customer_password != $password2)
      {
      echo "<script>alert('Password do not match!'); window.location='cust_signup.php'</script>";
      }else
    {
      mySQLi_query($conn, "INSERT INTO customer (customer_name, customer_email, customer_password)
      VALUES ('$customer_name','$customer_email','$customer_password')")
      or die (mysqli_error());
      echo "<script>alert('Account successfully created!'); window.location='cust_login.php'</script>";
    }
      
  }
  
?>

 