<?php include ('session.php');

$select=mysqli_query($conn, "select * from domain where customer_id='$customer_id'");
$selected=mysqli_fetch_assoc($select);


?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="css/versions.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!-- Modernizer for Portfolio -->
    <script src="js/modernizer.js"></script>

    <style>
        .div2{
    background-color: greenyellow;
}
    </style>
   
</head>

<body>

 
    <!-- Start header -->
    <header class="top-navbar">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.html">
                    <!-- <img src="images/logo-hosting.png" alt="" /> -->
                    <b><h1 style="color: white;">WEBSERVER</h1><b></b>
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbars-host" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbars-host">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active"><a class="nav-link" href="index.html">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#"><?php echo $customer_name ?></a></li>
                        <li class="nav-item"><a class="nav-link" href="cust_tickets.php">Tickets</a></li>
                        
                        <!-- <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li> -->
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a class="hover-btn-new log" href="logout.php"><span>Log Out</span></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- End header -->
  




            <section class="main" id="content">

<div class="jumbotron">
<h1 class="display-4"><b>http://<?php  echo $selected['domain_name'] ?></b> </h1>
 <!--  <h1 class="display-4"><b>http://<?php  echo "Domain Name Here" ?></b> </h1> -->
  <p class="lead">information.</p>
  <hr class="my-4">
  <p class="lead">
    <a class="btn btn-primary btn-lg" href="view_domain.php" role="button">Back</a>
  </p>
</div><br><br><br>
               


        <form class="form-control" method="post" action="" enctype="multipart/form-data">
            <fieldset>
                <legend>Payments Here</legend>
                <div class="form-control">
                    <input type="text" id="amount" for="amount" placeholder="Enter amount" name="amount" required>
                    <span id="id-warning"
                    style="color: red; visibility: visible; font-weight: bold;"><small></small></span></br></br>
                </div>
                <div class="form-control" style="margin-top: 15px;">
                    <input type="text" id="agent_id" for="agent_id" placeholder="Enter Agent ID" name="agent_id" required>
                    <span id="id-warning"
                    style="color: red; visibility: visible; font-weight: bold;"><small></small></span></br></br>
                </div>
               
                
                <button style="margin-left: 10px; margin-top: 10px; background-color:darkblue;" id="addbtn" name="submit"  type="submit" required>Comfirm Payments</button><br>
                <!--<span  id="warning" style="color: red; visibility: hidden; font-weight: bold;">*All fields are required</span><br> -->
            </fieldset>
    </form><br><br><br>




    <?php
   

   

if(isset($_POST['submit']))
{
    

$amount=$_POST['amount'];
$agent_id=$_POST['agent_id'];


$sql=mysqli_query($conn, "insert into payment (amount, agent_id, customer_id, domain_id)
                          values('$amount', '$agent_id', '$customer_id', '$domain_id')");
    if($sql)
    {
        echo "<script>alert('Record sent Successfully, wait till verification is done'); window.location='cust_home.php'</script>";
        // echo "successfully";
    }
    else 
    {
        echo "<script>alert('error saving record '); window.location='payment.php'</script>".mysqli_error($conn);
    }


}

?>


    







           
            </section>


    
    <script src="">
        let tbn = document.getElementsByClassName("delbtn");
        btn.addEventListener('click', function (params) {

        })
    </script>
     <script src="javascript.js"></script>
</body>
</html>



 
