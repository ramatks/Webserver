<?php
 include ('session.php');
 include("includes/database.php");

$pid=$_GET['id'];
$select2=mysqli_query($conn,"select * from domain where domain_id='$pid' ");
$result2=mysqli_fetch_array($select2);

 $select=mysqli_query($conn, "select * from domain where customer_id='$customer_id'");
 $selected=mysqli_fetch_assoc($select);



   if(isset($_POST['submit']))
{
    

  $domain_name=$_POST['domain_name'];
  // $domain_duration=$_POST['domain_duration'];
// $end = date('d,m,Y', strtotime('+1 years'));
// $category=$_POST['category'];
// $price=$_POST['price'];
// $desc=$_POST['desc'];


//     if(empty($_FILES['domain_file']['tmp_name'])){
//     echo"<script>alert('upload a file first'); window.location='cust_home.php'</script>";
//     die();
// }

  if(!empty($_FILES['domain_file']['tmp_name'])){
            $picture_file1 = $_FILES['domain_file']['tmp_name'];
            $picture_name1 = $_FILES['domain_file']['name'];
            $temp1 = explode(".", $picture_name1);
            $newfilename1 = round(microtime(true)) . '.' . end($temp1);
            $path = "upload/$domain_name";
            if(!file_exists($path)) {
                mkdir($path, 0755, true);
            }
            move_uploaded_file($_FILES["domain_file"]["tmp_name"], "upload/".$domain_name."/"  .$newfilename1);
      }


      $sql=mysqli_query($conn, "update domain set domain_file='$newfilename1' where domain_id='$pid'");
    if($sql)
    {
        // header("location:cust_home.php");
        echo "<script>alert('Record is Updated Successfully'); window.location='cust_home.php'</script>";
        // echo "SUCESS";
    }
    else 
    {
        // echo "error Updating record ".mysqli_error($link);
        echo "<script>alert('error saving record '); window.location='cust_home.php'</script>".mysqli_error($conn);
         // echo "FAILURE".mysqli_error($conn);
    }
}


?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="css/versions.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!-- Modernizer for Portfolio -->
    <script src="js/modernizer.js"></script>

    <style>
        .div2{
    background-color: greenyellow;
}
    </style>
   
</head>

<body>

 
    <!-- Start header -->
    <header class="top-navbar">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.html">
                    <!-- <img src="images/logo-hosting.png" alt="" /> -->
                    <b><h1 style="color: white;">WEBSERVER</h1><b></b>
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbars-host" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbars-host">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active"><a class="nav-link" href="index.html">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#"><?php echo $customer_name ?></a></li>
                        <li class="nav-item"><a class="nav-link" href="cust_tickets.php">Tickets</a></li>
                       
                        
                        <!-- <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li> -->
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a class="hover-btn-new log" href="logout.php"><span>Log Out</span></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- End header -->



            <section class="main" id="content">

                 <div class="jumbotron">
                  <h2 style="color: red;">You are about to edit the files of </h2><h1 class="display-4"><b>http://<?php  echo $result2['domain_name'] ?></b> </h1>
                  <p class="lead">information.</p>
                  <hr class="my-4">
                  <p class="lead">
                    <a class="btn btn-primary btn-lg" href="cust_home.php" role="button">Back</a>
                  </p>
                </div><br><br><br>
               


        <form class="form-control" method="POST" action="" enctype="multipart/form-data">
            <fieldset>
                <legend>Upload a New file  to replace the old one</legend>
                <div class="form-control">
                    <!-- <input type="text" id="pname" for="name" placeholder="<?php  echo $result2['domain_name'] ?>" name="domain_name" disabled> -->
                    <input type="text" id="pname" for="name" placeholder="domain.com" name="domain_name" required>
                    <span id="id-warning"
                    style="color: red; visibility: visible; font-weight: bold;"><small></small></span></br></br>
                </div>
              
                <div style="margin-top: 10px;">
                    <!-- <label for="formFileLg" class="form-label"><h1>daraz.com</h1></label> -->
                    <input class="form-control form-control-lg" id="formFileLg" type="file" name="domain_file" for="domain_file" accept=“zip/*”>
                    
                </div>
                
                <button style="margin-left: 10px; margin-top: 10px; background-color:darkblue;" id="addbtn" name="submit"  type="submit" required>Update</button><br> 
                <!-- <a href="edit_process.php?id=<?php echo $selected['domain_id']; ?>"><button style="margin-left: 10px; margin-top: 10px; background-color:darkblue;" type="submit" name="submit" class="btn btn-success btn-sm">UPDATE</button></a>
 -->                <!--<span  id="warning" style="color: red; visibility: hidden; font-weight: bold;">*All fields are required</span><br> -->
            </fieldset>
    </form><br><br><br>
    <?php
    $date = date('d,m,Y');
    $invoice_no = rand(10000,99999);
    // echo"$date";
    
    // $end = date('d,m,Y', strtotime('+$domain_duration years'));
    // $end = date('d,m,Y', strtotime('+1 years'));

   

// if(isset($_POST['submit']))
// {
    

// $domain_name=$_POST['domain_name'];
// $domain_duration=$_POST['domain_duration'];
// $end = date('d,m,Y', strtotime('+1 years'));
// // $category=$_POST['category'];
// // $price=$_POST['price'];
// // $desc=$_POST['desc'];


// //     if(empty($_FILES['domain_file']['tmp_name'])){
// //     echo"<script>alert('upload a file first'); window.location='cust_home.php'</script>";
// //     die();
// // }

//   if(!empty($_FILES['domain_file']['tmp_name'])){
//             $picture_file1 = $_FILES['domain_file']['tmp_name'];
//             $picture_name1 = $_FILES['domain_file']['name'];
//             $temp1 = explode(".", $picture_name1);
//             $newfilename1 = round(microtime(true)) . '.' . end($temp1);
//             $path = "upload/$domain_name";
//             if(!file_exists($path)) {
//                 mkdir($path, 0755, true);
//             }
//             move_uploaded_file($_FILES["domain_file"]["tmp_name"], "upload/".$domain_name."/"  .$newfilename1);
//       }



// $sql=mysqli_query($link, "update domain set domain_file='$newfilename1' where id='$pid'");
//     if($sql)
//     {
//         // header("location:cust_home.php");
//         echo "<script>alert('Record is Updated Successfully'); window.location='edit.php'</script>";
//     }
//     else 
//     {
//         // echo "error Updating record ".mysqli_error($link);
//         echo "<script>alert('error saving record '); window.location='edit.php'</script>".mysqli_error($conn);
//     }


  
      


//  $sql1=mysqli_query($conn, "select * from domain WHERE domain_name='$domain_name'") or die (mysqli_error($conn));
//       $row=mysqli_num_rows($sql1);
//       if ($row > 0)
//       {
//       echo "<script>alert('Domain already Taken!'); window.location='cust_home.php'</script>";
//       }
//       else

// {
// $sql=mysqli_query($conn, "insert into domain (domain_name, domain_file, customer_id, start_date, end_date, domain_duration, invoice_no)
//                           values('$domain_name', '$newfilename1', '$customer_id',  '$date', '$end', '$domain_duration', '$invoice_no')");
//     if($sql)
//     {
//         echo "<script>alert('Record is saved Successful'); window.location='cust_home.php'</script>";
//         // echo "successfully";
//     }
//     else 
//     {
//         echo "<script>alert('error saving record '); window.location='cust_home.php'</script>".mysqli_error($conn);
//     }

// }


      


//  $sql1=mysqli_query($conn, "select * from domain WHERE domain_name='$domain_name'") or die (mysqli_error($conn));
//       $row=mysqli_num_rows($sql1);
//       if ($row > 0)
//       {
//       echo "<script>alert('Domain already Taken!'); window.location='cust_home.php'</script>";
//       }
//       else

// {
// $sql=mysqli_query($conn, "insert into domain (domain_name, domain_file, customer_id, start_date, end_date, domain_duration, invoice_no)
//                           values('$domain_name', '$newfilename1', '$customer_id',  '$date', '$end', '$domain_duration', '$invoice_no')");
//     if($sql)
//     {
//         echo "<script>alert('Record is saved Successful'); window.location='cust_home.php'</script>";
//         // echo "successfully";
//     }
//     else 
//     {
//         echo "<script>alert('error saving record '); window.location='cust_home.php'</script>".mysqli_error($conn);
//     }

// }



?>             


            </section>


    
    <script src="">
        let tbn = document.getElementsByClassName("delbtn");
        btn.addEventListener('click', function (params) {

        })
    </script>
     <script src="javascript.js"></script>
</body>
</html>



 
