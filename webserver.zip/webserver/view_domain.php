<?php include ('session.php');

$pid=$_GET['id'];
$select2=mysqli_query($conn,"select * from domain where domain_id='$pid' ");
$result2=mysqli_fetch_array($select2);


?>



,
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="css/versions.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!-- Modernizer for Portfolio -->
    <script src="js/modernizer.js"></script>

    <style>
        .div2{
    background-color: greenyellow;
}
    </style>
   
</head>

<body>

 
    <!-- Start header -->
    <header class="top-navbar">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="cust_home.php">
                    <!-- <img src="images/logo-hosting.png" alt="" /> -->
                    <b><h1 style="color: white;">WEBSERVER</h1><b></b>
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbars-host" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbars-host">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active"><a class="nav-link" href="index.php">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#"><?php echo $customer_name ?></a></li>
                         <li class="nav-item"><a class="nav-link" href="cust_tickets.php">Tickets</a></li>
                        
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"></a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a class="hover-btn-new log" href="logout.php"><span>Log Out</span></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- End header -->



            <section class="main" id="content">
               


       <div class="jumbotron">
  <h1 class="display-4"><b>http://<?php  echo $result2['domain_name'] ?></b> </h1>
  <p class="lead">information.</p>
  <hr class="my-4">
  <p class="lead">
    <a class="btn btn-primary btn-lg" href="cust_home.php" role="button">Back</a>
  </p>
</div><br><br><br>

 






           <h1 style="color: red;"><strong>Domain Details</strong></h1>
          
            <table id="tab">
            <thead>
            <th>#</th>
            <th>DOMAIN NAME</th>
            <th>START DATE</th>
            <th>END DATE</th>
            <th>INVOICE NUMBER</th>
            <th>OPTIONS</th>
            </thead>
            <tbody>

             

<?php $sn='@'; ?>


      <tr>
            <td><?php  echo $sn ?></td>
            <td><?php  echo $result2['domain_name'] ?> </td>
            <td><?php  echo $result2['start_date'] ?> </td>
            <td><?php  echo $result2['end_date'] ?> </td>
            <td><?php  echo $result2['invoice_no'] ?> </td>
            <td align=""><a href="payment.php"><button type="submit" name="submit" class="btn btn-primary btn-sm">Proceed to Payment</button></a>
           <!--  <a href="../examples/viewproduct.php?id=<?php echo $result['id']; ?>"><button type="submit" name="submit" class="btn btn-success btn-sm">View</button></a>
            </tr> -->


            </tbody>
            </table><br><br><br><br>
            </section>


    
    <script src="">
        let tbn = document.getElementsByClassName("delbtn");
        btn.addEventListener('click', function (params) {

        })
    </script>
     <script src="javascript.js"></script>
</body>
</html>



 
